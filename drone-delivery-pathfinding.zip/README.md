
# drone-delivery-pathfinding

A Pygame-based simulation that visualizes a drone delivering to a destination using the A* pathfinding algorithm. Includes interactive controls for setting start and end points, placing obstacles, and running the simulation.

## Features
- A* pathfinding algorithm
- Visual drone movement animation
- Start, end, and obstacle placement via UI
- Status messages and completion effects

## Requirements
- Python 3.x
- Pygame (`pip install pygame`)

## How to Run
```bash
python src/main.py
```

## Controls
- Click **Start**, then a grid cell to set the start point.
- Click **End**, then a grid cell to set the destination.
- Click **Obstacle**, then cells to add obstacles.
- Click **Run** to start the drone delivery.
- Click **Reset** to clear everything.
